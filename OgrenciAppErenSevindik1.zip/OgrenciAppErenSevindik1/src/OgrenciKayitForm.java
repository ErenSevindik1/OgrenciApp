import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OgrenciKayitFormu extends JFrame {
    private JLabel ogrenciNoLabel;
    private JLabel ogrenciAdLabel;
    private JLabel ogrenciSoyadLabel;
    private JLabel ogrenciBolumLabel;
    private JLabel ogrenciDerslerLabel;
    private JTextField ogrenciNoField;
    private JTextField ogrenciAdField;
    private JTextField ogrenciSoyadField;
    private JTextField ogrenciBolumField;
    private JComboBox<String> derslerComboBox;
    private JButton kaydetButton;

    public OgrenciKayitFormu() {
        setTitle("Öğrenci Kayıt Formu");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 250);

        ogrenciNoLabel = new JLabel("Öğrenci No:");
        ogrenciAdLabel = new JLabel("Öğrenci Adı:");
        ogrenciSoyadLabel = new JLabel("Öğrenci Soyadı:");
        ogrenciBolumLabel = new JLabel("Öğrenci Bölümü:");
        ogrenciDerslerLabel = new JLabel("Dersler:");

        ogrenciNoField = new JTextField(20);
        ogrenciAdField = new JTextField(20);
        ogrenciSoyadField = new JTextField(20);
        ogrenciBolumField = new JTextField(20);
        derslerComboBox = new JComboBox<>(new String[]{"Matematik", "Fizik", "Kimya"}); // Derslerin listesi buraya eklenecek
        kaydetButton = new JButton("Kaydet");

        setLayout(new java.awt.GridLayout(6, 2));
        add(ogrenciNoLabel);
        add(ogrenciNoField);
        add(ogrenciAdLabel);
        add(ogrenciAdField);
        add(ogrenciSoyadLabel);
        add(ogrenciSoyadField);
        add(ogrenciBolumLabel);
        add(ogrenciBolumField);
        add(ogrenciDerslerLabel);
        add(derslerComboBox);
        add(new JLabel()); // Boş label ekleyerek düzeni sağla
        add(kaydetButton);

        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Ogrenci ogrenci = new Ogrenci();
                ogrenci.setOgrenciNo(ogrenciNoField.getText());
                ogrenci.setOgrenciAd(ogrenciAdField.getText());
                ogrenci.setOgrenciSoyad(ogrenciSoyadField.getText());
                ogrenci.setOgrenciBolum(ogrenciBolumField.getText());
                ogrenci.setOgrenciDersler((String) derslerComboBox.getSelectedItem());

                // Ogrenci nesnesini dosyaya kaydetme işlemi
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ogrenciler.dat"))) {
                    oos.writeObject(ogrenci);
                    JOptionPane.showMessageDialog(null, "Öğrenci kaydedildi.");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Öğrenci kaydedilemedi.");
                }
            }
        });
    }
}
