import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("Main Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Create and configure the "Course Registration Form" button
        JButton btnCourseRegistration = new JButton("Course Registration Form");
        btnCourseRegistration.addActionListener(e -> new CourseRegistrationForm());
        configureButtonConstraints(gbc, 0, 0);
        frame.add(btnCourseRegistration, gbc);

        // Create and configure the "Student Registration Form" button
        JButton btnStudentRegistration = new JButton("Student Registration Form");
        btnStudentRegistration.addActionListener(e -> new StudentRegistrationForm());
        configureButtonConstraints(gbc, 0, 1);
        frame.add(btnStudentRegistration, gbc);

        // Set frame properties and make it visible
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Helper method to configure button constraints
    private static void configureButtonConstraints(GridBagConstraints gbc, int x, int y) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.insets = new Insets(10, 10, 10, 10); // Margin
    }
}

class CourseRegistrationForm extends JFrame {
    public CourseRegistrationForm() {
        // Implementation of the course registration form
        // ...
        // Example: JOptionPane.showMessageDialog(this, "Course Registration Form opened");
    }
}

class StudentRegistrationForm extends JFrame {
    public StudentRegistrationForm() {
        // Implementation of the student registration form
        // ...
        // Example: JOptionPane.showMessageDialog(this, "Student Registration Form opened");
    }
}
