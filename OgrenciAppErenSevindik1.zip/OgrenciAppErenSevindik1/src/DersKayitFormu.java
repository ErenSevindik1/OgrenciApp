import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DersKayitFormu extends JFrame {
    private JLabel dersKoduLabel;
    private JLabel dersAdLabel;
    private JLabel dersDonemLabel;
    private JTextField dersKoduField;
    private JTextField dersAdField;
    private JTextField dersDonemField;
    private JButton kaydetButton;

    public DersKayitFormu() {
        setTitle("Ders Kayıt Formu");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);

        dersKoduLabel = new JLabel("Ders Kodu:");
        dersAdLabel = new JLabel("Ders Adı:");
        dersDonemLabel = new JLabel("Ders Dönemi:");

        dersKoduField = new JTextField(20);
        dersAdField = new JTextField(20);
        dersDonemField = new JTextField(20);
        kaydetButton = new JButton("Kaydet");

        setLayout(new java.awt.GridLayout(4, 2));
        add(dersKoduLabel);
        add(dersKoduField);
        add(dersAdLabel);
        add(dersAdField);
        add(dersDonemLabel);
        add(dersDonemField);
        add(new JLabel()); // Boş label ekleyerek düzeni sağla
        add(kaydetButton);

        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Ders ders = new Ders();
                ders.setDersKodu(dersKoduField.getText());
                ders.setDersAd(dersAdField.getText());
                ders.setDersDonem(dersDonemField.getText());

                // Ders nesnesini dosyaya kaydetme işlemi
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("dersler.dat"))) {
                    oos.writeObject(ders);
                    JOptionPane.showMessageDialog(null, "Ders kaydedildi.");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Ders kaydedilemedi.");
                }
            }
        });
    }
}
